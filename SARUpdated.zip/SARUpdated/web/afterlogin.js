$(document).ready(function(){
	$('#t1').mouseenter(function(){
		$('#studimg').animate({height:'220px',width:'220px'});
		});
	$('#t1').mouseleave(function(){
		$('#studimg').animate({height:'200px',width:'200px'});
		});
        });